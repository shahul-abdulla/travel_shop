<?php echo e($slot); ?>

<?php /**PATH D:\freelance projects\0working folder\Travel Shop\travel_shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>