
<div id="search1">
    <button type="button" class="close">×</button>
    <form>
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit"  wire:model="searchQuery"  class="btn btn-primary">Search</button>
    </form>
    
</div><?php /**PATH D:\freelance projects\0working folder\Travel Shop\travel_shop\resources\views/livewire/package-search.blade.php ENDPATH**/ ?>