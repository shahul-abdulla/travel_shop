<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\freelance projects\0working folder\Travel Shop\travel_shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>